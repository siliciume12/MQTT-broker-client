
from machine import Pin, I2C
from bmp280 import BMP280
from temp import bmp

import time
import network
from umqtt.robust import MQTTClient

ssid = "TP-Link_02D9"
password = "47240308"

i2c = I2C(0, scl=Pin(22), sda=Pin(21))
bmp = BMP280(i2c)
time.sleep(2)

# Initialiser la connexion Wi-Fi
wlan = network.WLAN(network.STA_IF)#1
wlan.active(True)#2
wlan.connect(ssid, password)#3
# Créer une interface Wi-Fi en mode station (client)
# Attendre la connexion
while not wlan.isconnected():
    
    
    time.sleep(1)
    print("Connexion en cours...")

print("Connecté !")
print("Paramètres IP :", wlan.ifconfig())

time.sleep(1)


# Infos MQTT
MQTT_BROKER = "192.168.1.106"  # IP de ta Raspberry Pi / broker
MQTT_PORT = 1883
MQTT_USER = "user1"
MQTT_PASSWORD = "user1"
MQTT_CLIENT_ID = "esp32_client"
MQTT_TOPIC = "broker/esp32-1/temperature"


temp = str(bmp.temperature)



client = MQTTClient(MQTT_CLIENT_ID, MQTT_BROKER, port=MQTT_PORT, user=MQTT_USER, password=MQTT_PASSWORD)


while True:
    temp = str(bmp.temperature)
    try:
        client.connect()
        print("Connecté au broker MQTT")

        # Publication d'un message
        message = "temperature :" + temp  + "°C"
        client.publish(MQTT_TOPIC, message.encode())
        print("Message publié:", message)
        time.sleep(3)
        #client.disconnect()
        #print("Déconnecté proprement")

    except Exception as e:
        print("Erreur MQTT:", e)
