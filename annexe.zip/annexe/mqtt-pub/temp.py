from machine import Pin, I2C
from bmp280 import BMP280
import time

i2c = I2C(0, scl=Pin(22), sda=Pin(21))
bmp = BMP280(i2c)
time.sleep(2)
#while True:
    
    #print("Température:", bmp.temperature, "°C")
    #print("Pression:", bmp.pressure, "hPa")
    #time.sleep(1)
