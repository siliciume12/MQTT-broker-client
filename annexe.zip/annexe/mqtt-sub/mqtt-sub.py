import network
import time
from umqtt.robust import MQTTClient

# --- Configuration Wi-Fi ---
SSID = " TP-Link_02D9"
PASSWORD = "47240308"

# --- Configuration MQTT ---
MQTT_BROKER = "192.168.1.106"
MQTT_PORT = 1883
MQTT_USER = "user1"
MQTT_PASSWORD = "user1"
MQTT_CLIENT_ID = "esp32_subscriber"
MQTT_TOPIC = b"broker/esp32-1/temperature"  # Le topic auquel on s'abonne 

# --- Connexion au Wi-Fi ---
wlan = network.WLAN(network.STA_IF)
wlan.active(True)
wlan.connect(SSID, PASSWORD)

print("Connexion Wi-Fi...")
while not wlan.isconnected():
    time.sleep(1)
    print("...")

print("Connecté au Wi-Fi :", wlan.ifconfig())

# --- Fonction appelée quand un message est reçu ---
def message_recu(topic, msg):
    print("Message reçu sur le topic :", topic.decode())
    print("Contenu :", msg.decode())

# --- Connexion au broker MQTT ---
client = MQTTClient(MQTT_CLIENT_ID, MQTT_BROKER, port=MQTT_PORT,user=MQTT_USER, password=MQTT_PASSWORD)
client.set_callback(message_recu)
client.connect()
print("Connecté au broker MQTT")

# --- S'abonner au topic ---
client.subscribe(MQTT_TOPIC)
print("Abonné au topic :", MQTT_TOPIC.decode())

# --- Boucle principale : attend les messages MQTT ---
try:
    while True:
        #client.wait_msg()  # Bloque jusqu’à réception d’un message
        client.check_msg()  # ➜ Utilise ça si tu veux une boucle non-bloquante
except Exception as e:
    print("Erreur MQTT :", e)
    client.disconnect()
